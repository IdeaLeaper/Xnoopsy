<?php
define("mysql_host","localhost");
define("mysql_user","root");
define("mysql_pass","");
define("mysql_db","xnoopsy");
header('Content-type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST');
?>